#!/usr/bin/env python3
"""
TestLink Optimized Execution Module - Python Backend
FastAPI-based microservice for high-performance test execution

Features:
- Async database operations with connection pooling
- Environment-based configuration
- Comprehensive error handling and logging
- Performance monitoring and metrics
- CORS support for frontend integration
- Health checks and API documentation
"""

import os
import sys
import logging
import asyncio
import json
from datetime import datetime
from typing import List, Dict, Optional, Any
from pathlib import Path

# Add current directory to Python path for imports
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from fastapi import FastAPI, HTTPException, Query, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.middleware.gzip import GZipMiddleware
import mysql.connector
from mysql.connector import pooling, Error
from pydantic import BaseModel
import uvicorn

# Import configuration
from config import config, DatabaseConfig, ServerConfig, CORSConfig

# Setup logging
def setup_logging():
    """Setup application logging"""
    log_dir = Path(config.logging.LOG_FILE).parent
    log_dir.mkdir(exist_ok=True)
    
    logging.basicConfig(
        level=getattr(logging, config.server.LOG_LEVEL.upper()),
        format=config.logging.LOG_FORMAT,
        handlers=[
            logging.FileHandler(config.logging.LOG_FILE),
            logging.StreamHandler()
        ]
    )

setup_logging()
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title=config.TITLE,
    description=config.DESCRIPTION,
    version=config.VERSION,
    docs_url="/docs" if config.features.ENABLE_API_DOCS else None,
    redoc_url="/redoc" if config.features.ENABLE_API_DOCS else None
)

# Add middleware
if config.features.ENABLE_METRICS:
    app.add_middleware(GZipMiddleware, minimum_size=1000)

app.add_middleware(
    CORSMiddleware,
    **config.cors.get_cors_config()
)

# Database connection pool
connection_pool = None

def create_connection_pool():
    """Create database connection pool"""
    global connection_pool
    
    try:
        db_config = DatabaseConfig.get_connection_config()
        connection_pool = mysql.connector.pooling.MySQLConnectionPool(**db_config)
        logger.info("Database connection pool created successfully")
        
        # Validate configuration
        warnings = config.validate_config()
        if warnings:
            logger.warning("Configuration warnings:")
            for warning in warnings:
                logger.warning(f"  - {warning}")
        
        return True
        
    except Exception as e:
        logger.error(f"Failed to create connection pool: {e}")
        return False

# Initialize connection pool on startup
@app.on_event("startup")
async def startup_event():
    """Initialize application on startup"""
    logger.info("Starting TestLink Optimized Execution API...")
    
    if not create_connection_pool():
        logger.error("Failed to initialize database connection pool")
        raise Exception("Database initialization failed")
    
    logger.info(f"Server starting on {config.server.HOST}:{config.server.PORT}")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    logger.info("Shutting down TestLink Optimized Execution API...")
    
    if connection_pool:
        try:
            connection_pool._remove_connections()
            logger.info("Database connection pool closed")
        except Exception as e:
            logger.error(f"Error closing connection pool: {e}")

# Pydantic models for request/response
class ExecutionUpdate(BaseModel):
    tcversion_id: int
    tplan_id: int
    build_id: int
    platform_id: int
    status: str
    notes: Optional[str] = ""

class TreeNode(BaseModel):
    id: int
    name: str
    type: str
    status: Optional[str] = None
    testcase_count: int = 0
    has_children: bool = False

class TestCase(BaseModel):
    id: int
    name: str
    summary: Optional[str] = ""
    preconditions: Optional[str] = ""
    version: int = 1
    author_login: Optional[str] = ""
    creation_ts: Optional[str] = ""

class TestStep(BaseModel):
    id: int
    step_number: int
    actions: str
    expected_results: str
    execution_type: int = 1

class Execution(BaseModel):
    id: Optional[int] = None
    status: str
    execution_ts: Optional[str] = None
    notes: Optional[str] = ""
    tester_id: Optional[int] = None
    tester_login: Optional[str] = ""
    duration: int = 0

class TestCaseResponse(BaseModel):
    success: bool
    testcase: TestCase
    steps: List[TestStep]
    execution: Optional[Execution] = None

class TreeResponse(BaseModel):
    success: bool
    nodes: List[TreeNode]

class StatsResponse(BaseModel):
    success: bool
    stats: Dict[str, int]

# Database helper functions
async def get_db_connection():
    """Get database connection from pool"""
    if not connection_pool:
        raise HTTPException(status_code=500, detail="Database connection pool not available")
    
    try:
        connection = connection_pool.get_connection()
        return connection
    except Exception as e:
        logger.error(f"Failed to get database connection: {e}")
        raise HTTPException(status_code=500, detail="Database connection failed")

async def execute_query(query: str, params: tuple = None, fetch: str = "all") -> Any:
    """Execute database query with error handling"""
    connection = await get_db_connection()
    cursor = None
    
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute(query, params or ())
        
        if fetch == "all":
            result = cursor.fetchall()
        elif fetch == "one":
            result = cursor.fetchone()
        elif fetch == "many":
            result = cursor.fetchmany()
        else:
            result = None
            
        connection.commit()
        return result
        
    except Exception as e:
        logger.error(f"Query execution failed: {e}")
        connection.rollback()
        raise HTTPException(status_code=500, detail=f"Database query failed: {str(e)}")
    finally:
        if cursor:
            cursor.close()
        connection.close()

# API Endpoints
@app.get("/")
async def root():
    """Root endpoint"""
    return {"message": "TestLink Optimized Execution API", "version": "1.0.0"}

@app.get("/api/tree_nodes", response_model=TreeResponse)
async def get_tree_nodes(
    parent_id: int = Query(0, description="Parent node ID"),
    tplan_id: int = Query(1, description="Test plan ID"),
    build_id: int = Query(1, description="Build ID"),
    platform_id: int = Query(1, description="Platform ID")
):
    """Get tree nodes for lazy loading"""
    
    try:
        if parent_id == 0:
            # Get root test suites
            query = """
                SELECT nh.id, nh.name, 'testsuite' as type,
                       COUNT(DISTINCT tc.id) as testcase_count
                FROM nodes_hierarchy nh
                LEFT JOIN nodes_hierarchy child ON nh.id = child.parent_id
                LEFT JOIN testplan_tcversions tptc ON child.id = tptc.tcversion_id
                WHERE nh.parent_id = 0 
                  AND nh.node_type_id = 1
                  AND EXISTS (
                      SELECT 1 FROM testproject_suites tps 
                      WHERE tps.testproject_id = %s AND tps.testsuite_id = nh.id
                  )
                GROUP BY nh.id, nh.name
                ORDER BY nh.name
            """
            params = (1,)  # testproject_id - should come from session
        else:
            # Get child nodes
            query = """
                SELECT nh.id, nh.name, 
                       CASE WHEN nh.node_type_id = 2 THEN 'testcase' ELSE 'testsuite' END as type,
                       CASE WHEN nh.node_type_id = 2 THEN 
                           (SELECT status FROM executions e 
                            WHERE e.tcversion_id = nh.id 
                              AND e.testplan_id = %s 
                              AND e.build_id = %s 
                              AND e.platform_id = %s 
                            ORDER BY e.id DESC LIMIT 1)
                       ELSE NULL END as status,
                       CASE WHEN nh.node_type_id = 2 THEN 0 ELSE 
                           (SELECT COUNT(DISTINCT tc.id) 
                            FROM nodes_hierarchy tc 
                            WHERE tc.parent_id = nh.id AND tc.node_type_id = 2) 
                       END as testcase_count
                FROM nodes_hierarchy nh
                WHERE nh.parent_id = %s
                ORDER BY nh.node_type_id, nh.name
            """
            params = (tplan_id, build_id, platform_id, parent_id)
        
        results = await execute_query(query, params)
        
        nodes = []
        for row in results:
            nodes.append(TreeNode(
                id=row['id'],
                name=row['name'],
                type=row['type'],
                status=row.get('status', 'n'),
                testcase_count=row['testcase_count'] or 0,
                has_children=row['type'] == 'testsuite' and (row['testcase_count'] or 0) > 0
            ))
        
        return TreeResponse(success=True, nodes=nodes)
        
    except Exception as e:
        logger.error(f"Error getting tree nodes: {e}")
        return TreeResponse(success=False, nodes=[])

@app.get("/api/testcase/{tcversion_id}", response_model=TestCaseResponse)
async def get_testcase(
    tcversion_id: int,
    tplan_id: int = Query(1, description="Test plan ID"),
    build_id: int = Query(1, description="Build ID"),
    platform_id: int = Query(1, description="Platform ID")
):
    """Get test case details"""
    
    try:
        # Get test case details
        testcase_query = """
            SELECT tc.id, tc.name, tc.summary, tc.preconditions, tc.version,
                   tc.author_id, tc.creation_ts, tc.updater_id, tc.modification_ts,
                   tc.active, tc重要性, tc.urgency,
                   u1.login as author_login, u2.login as updater_login
            FROM tcversions tc
            LEFT JOIN users u1 ON tc.author_id = u1.id
            LEFT JOIN users u2 ON tc.updater_id = u2.id
            WHERE tc.id = %s
        """
        
        testcase_result = await execute_query(testcase_query, (tcversion_id,), "one")
        
        if not testcase_result:
            raise HTTPException(status_code=404, detail="Test case not found")
        
        # Get test steps
        steps_query = """
            SELECT id, step_number, actions, expected_results, execution_type
            FROM tcsteps 
            WHERE tcversion_id = %s
            ORDER BY step_number
        """
        
        steps_results = await execute_query(steps_query, (tcversion_id,))
        
        # Get latest execution
        execution_query = """
            SELECT e.id, e.status, e.execution_ts, e.notes, e.tester_id, e.duration,
                   u.login as tester_login
            FROM executions e
            LEFT JOIN users u ON e.tester_id = u.id
            WHERE e.tcversion_id = %s 
              AND e.testplan_id = %s 
              AND e.build_id = %s 
              AND e.platform_id = %s
            ORDER BY e.id DESC 
            LIMIT 1
        """
        
        execution_result = await execute_query(execution_query, (tcversion_id, tplan_id, build_id, platform_id), "one")
        
        # Build response objects
        testcase = TestCase(
            id=testcase_result['id'],
            name=testcase_result['name'],
            summary=testcase_result['summary'] or "",
            preconditions=testcase_result['preconditions'] or "",
            version=testcase_result['version'],
            author_login=testcase_result['author_login'] or "Unknown",
            creation_ts=str(testcase_result['creation_ts']) if testcase_result['creation_ts'] else ""
        )
        
        steps = []
        for step in steps_results:
            steps.append(TestStep(
                id=step['id'],
                step_number=step['step_number'],
                actions=step['actions'],
                expected_results=step['expected_results'],
                execution_type=step['execution_type']
            ))
        
        execution = None
        if execution_result:
            execution = Execution(
                id=execution_result['id'],
                status=execution_result['status'],
                execution_ts=str(execution_result['execution_ts']) if execution_result['execution_ts'] else "",
                notes=execution_result['notes'] or "",
                tester_id=execution_result['tester_id'],
                tester_login=execution_result['tester_login'] or "Unknown",
                duration=execution_result['duration'] or 0
            )
        
        return TestCaseResponse(
            success=True,
            testcase=testcase,
            steps=steps,
            execution=execution
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting test case: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get test case: {str(e)}")

@app.post("/api/execution")
async def update_execution(execution_data: ExecutionUpdate):
    """Update execution status"""
    
    try:
        # Validate status
        valid_statuses = ['p', 'f', 'b', 'n']
        if execution_data.status not in valid_statuses:
            raise HTTPException(status_code=400, detail="Invalid execution status")
        
        # Insert new execution record
        query = """
            INSERT INTO executions (testplan_id, tcversion_id, build_id, platform_id, 
                                   status, notes, tester_id, execution_ts, duration) 
            VALUES (%s, %s, %s, %s, %s, %s, %s, NOW(), 0)
        """
        
        params = (
            execution_data.tplan_id,
            execution_data.tcversion_id,
            execution_data.build_id,
            execution_data.platform_id,
            execution_data.status,
            execution_data.notes,
            1  # tester_id - should come from session
        )
        
        await execute_query(query, params)
        
        return {"success": True, "message": "Execution updated successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating execution: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to update execution: {str(e)}")

@app.get("/api/stats", response_model=StatsResponse)
async def get_stats(
    tplan_id: int = Query(1, description="Test plan ID"),
    build_id: int = Query(1, description="Build ID"),
    platform_id: int = Query(1, description="Platform ID")
):
    """Get execution statistics"""
    
    try:
        # Get execution counts by status
        stats_query = """
            SELECT e.status, COUNT(*) as count 
            FROM executions e
            JOIN testplan_tcversions tptc ON e.testplan_id = tptc.testplan_id 
                                           AND e.tcversion_id = tptc.tcversion_id
            WHERE e.testplan_id = %s 
              AND e.build_id = %s 
              AND e.platform_id = %s
            GROUP BY e.status
        """
        
        results = await execute_query(stats_query, (tplan_id, build_id, platform_id))
        
        stats = {
            'passed': 0,
            'failed': 0,
            'blocked': 0,
            'not_run': 0,
            'total': 0
        }
        
        for row in results:
            switch = {
                'p': 'passed',
                'f': 'failed',
                'b': 'blocked',
                'n': 'not_run'
            }
            status_key = switch.get(row['status'])
            if status_key:
                stats[status_key] = row['count']
        
        # Get total test cases
        total_query = "SELECT COUNT(*) as total FROM testplan_tcversions WHERE testplan_id = %s"
        total_result = await execute_query(total_query, (tplan_id,), "one")
        stats['total'] = total_result['total'] if total_result else 0
        
        # Calculate not run from total minus executed
        executed = stats['passed'] + stats['failed'] + stats['blocked']
        stats['not_run'] = max(0, stats['total'] - executed)
        
        return StatsResponse(success=True, stats=stats)
        
    except Exception as e:
        logger.error(f"Error getting stats: {e}")
        return StatsResponse(success=False, stats={})

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    try:
        # Test database connection
        connection = await get_db_connection()
        connection.close()
        return {"status": "healthy", "database": "connected"}
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return JSONResponse(
            status_code=503,
            content={"status": "unhealthy", "database": "disconnected", "error": str(e)}
        )

if __name__ == "__main__":
    import uvicorn
    
    # Run the server
    uvicorn.run(
        "python_backend:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
