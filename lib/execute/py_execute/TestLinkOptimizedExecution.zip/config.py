"""
Configuration Module for TestLink Optimized Execution Module
Handles environment variables and application settings
"""

import os
from typing import List, Optional
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class DatabaseConfig:
    """Database configuration settings"""
    
    HOST = os.getenv("DB_HOST", "localhost")
    PORT = int(os.getenv("DB_PORT", "3306"))
    USER = os.getenv("DB_USER", "testlink")
    PASSWORD = os.getenv("DB_PASSWORD", "")
    DATABASE = os.getenv("DB_NAME", "testlink")
    CHARSET = os.getenv("DB_CHARSET", "utf8mb4")
    
    # Connection pool settings
    POOL_SIZE = int(os.getenv("DB_POOL_SIZE", "10"))
    POOL_RESET_SESSION = os.getenv("DB_POOL_RESET_SESSION", "true").lower() == "true"
    CONNECTION_TIMEOUT = int(os.getenv("DB_CONNECTION_TIMEOUT", "30"))
    READ_TIMEOUT = int(os.getenv("DB_READ_TIMEOUT", "60"))
    
    @classmethod
    def get_connection_config(cls) -> dict:
        """Get database connection configuration"""
        return {
            "host": cls.HOST,
            "port": cls.PORT,
            "user": cls.USER,
            "password": cls.PASSWORD,
            "database": cls.DATABASE,
            "charset": cls.CHARSET,
            "pool_name": "testlink_pool",
            "pool_size": cls.POOL_SIZE,
            "pool_reset_session": cls.POOL_RESET_SESSION,
            "connection_timeout": cls.CONNECTION_TIMEOUT,
            "autocommit": True,
            "use_unicode": True
        }

class ServerConfig:
    """FastAPI server configuration"""
    
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", "8000"))
    DEBUG = os.getenv("DEBUG", "false").lower() == "true"
    RELOAD = os.getenv("RELOAD", "true").lower() == "true"
    LOG_LEVEL = os.getenv("LOG_LEVEL", "info")
    
    @classmethod
    def get_uvicorn_config(cls) -> dict:
        """Get uvicorn server configuration"""
        return {
            "host": cls.HOST,
            "port": cls.PORT,
            "reload": cls.RELOAD,
            "log_level": cls.LOG_LEVEL
        }

class CORSConfig:
    """CORS configuration"""
    
    ORIGINS = os.getenv("CORS_ORIGINS", "*").split(",")
    ALLOW_CREDENTIALS = os.getenv("CORS_ALLOW_CREDENTIALS", "true").lower() == "true"
    ALLOW_METHODS = os.getenv("CORS_ALLOW_METHODS", "*").split(",")
    ALLOW_HEADERS = os.getenv("CORS_ALLOW_HEADERS", "*").split(",")
    
    @classmethod
    def get_cors_config(cls) -> dict:
        """Get CORS middleware configuration"""
        return {
            "allow_origins": cls.ORIGINS,
            "allow_credentials": cls.ALLOW_CREDENTIALS,
            "allow_methods": cls.ALLOW_METHODS,
            "allow_headers": cls.ALLOW_HEADERS
        }

class TestLinkConfig:
    """TestLink integration settings"""
    
    SESSION_TIMEOUT = int(os.getenv("TESTLINK_SESSION_TIMEOUT", "3600"))
    DEFAULT_TESTPROJECT_ID = int(os.getenv("DEFAULT_TESTPROJECT_ID", "1"))
    DEFAULT_TESTPLAN_ID = int(os.getenv("DEFAULT_TESTPLAN_ID", "1"))
    DEFAULT_BUILD_ID = int(os.getenv("DEFAULT_BUILD_ID", "1"))
    DEFAULT_PLATFORM_ID = int(os.getenv("DEFAULT_PLATFORM_ID", "1"))

class PerformanceConfig:
    """Performance and optimization settings"""
    
    ENABLE_QUERY_CACHE = os.getenv("ENABLE_QUERY_CACHE", "true").lower() == "true"
    QUERY_CACHE_TTL = int(os.getenv("QUERY_CACHE_TTL", "300"))
    MAX_CONNECTION_RETRIES = int(os.getenv("MAX_CONNECTION_RETRIES", "3"))
    CONNECTION_RETRY_DELAY = int(os.getenv("CONNECTION_RETRY_DELAY", "1"))

class SecurityConfig:
    """Security configuration"""
    
    SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-here-change-in-production")
    JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
    JWT_EXPIRE_MINUTES = int(os.getenv("JWT_EXPIRE_MINUTES", "30"))

class LoggingConfig:
    """Logging configuration"""
    
    LOG_FILE = os.getenv("LOG_FILE", "logs/py_execute.log")
    LOG_MAX_SIZE = int(os.getenv("LOG_MAX_SIZE", "10485760"))  # 10MB
    LOG_BACKUP_COUNT = int(os.getenv("LOG_BACKUP_COUNT", "5"))
    LOG_FORMAT = os.getenv("LOG_FORMAT", "%(asctime)s - %(name)s - %(levelname)s - %(message)s")

class RateLimitConfig:
    """API rate limiting configuration"""
    
    ENABLED = os.getenv("RATE_LIMIT_ENABLED", "true").lower() == "true"
    REQUESTS = int(os.getenv("RATE_LIMIT_REQUESTS", "100"))
    WINDOW = int(os.getenv("RATE_LIMIT_WINDOW", "60"))  # seconds

class FeatureFlags:
    """Feature flags for enabling/disabling features"""
    
    ENABLE_METRICS = os.getenv("ENABLE_METRICS", "true").lower() == "true"
    ENABLE_HEALTH_CHECK = os.getenv("ENABLE_HEALTH_CHECK", "true").lower() == "true"
    ENABLE_API_DOCS = os.getenv("ENABLE_API_DOCS", "true").lower() == "true"
    ENABLE_PERFORMANCE_MONITORING = os.getenv("ENABLE_PERFORMANCE_MONITORING", "true").lower() == "true"

class AppConfig:
    """Main application configuration"""
    
    # Application info
    TITLE = "TestLink Optimized Execution API"
    DESCRIPTION = "High-performance backend for test execution module"
    VERSION = "1.0.0"
    
    # Sub-configurations
    database = DatabaseConfig()
    server = ServerConfig()
    cors = CORSConfig()
    testlink = TestLinkConfig()
    performance = PerformanceConfig()
    security = SecurityConfig()
    logging = LoggingConfig()
    rate_limit = RateLimitConfig()
    features = FeatureFlags()
    
    @classmethod
    def validate_config(cls) -> List[str]:
        """Validate configuration and return list of warnings"""
        warnings = []
        
        # Check database configuration
        if not cls.database.PASSWORD:
            warnings.append("Database password is not set")
        
        # Check security
        if cls.security.SECRET_KEY == "your-secret-key-here-change-in-production":
            warnings.append("Using default secret key - change in production")
        
        # Check required directories
        log_dir = os.path.dirname(cls.logging.LOG_FILE)
        if not os.path.exists(log_dir):
            warnings.append(f"Log directory does not exist: {log_dir}")
        
        return warnings

# Global configuration instance
config = AppConfig()
