"""
Database Module for TestLink Optimized Execution Module
Handles all database operations with connection pooling and error handling
"""

import asyncio
import logging
from typing import List, Dict, Optional, Any, Tuple
from contextlib import contextmanager
import mysql.connector
from mysql.connector import pooling, Error
from config import config, DatabaseConfig

logger = logging.getLogger(__name__)

class DatabaseManager:
    """Database connection manager with pooling and retry logic"""
    
    def __init__(self):
        self.connection_pool = None
        self._initialize_pool()
    
    def _initialize_pool(self):
        """Initialize database connection pool"""
        try:
            db_config = DatabaseConfig.get_connection_config()
            self.connection_pool = mysql.connector.pooling.MySQLConnectionPool(**db_config)
            logger.info("Database connection pool initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize database pool: {e}")
            raise
    
    @contextmanager
    def get_connection(self):
        """Get database connection from pool with automatic cleanup"""
        connection = None
        try:
            connection = self.connection_pool.get_connection()
            yield connection
        except Error as e:
            logger.error(f"Database connection error: {e}")
            if connection:
                connection.rollback()
            raise
        finally:
            if connection:
                connection.close()
    
    async def execute_query(
        self, 
        query: str, 
        params: Optional[Tuple] = None, 
        fetch: str = "all",
        retry_count: int = 0
    ) -> Any:
        """Execute database query with retry logic"""
        
        if retry_count >= config.performance.MAX_CONNECTION_RETRIES:
            raise Exception(f"Max retries ({config.performance.MAX_CONNECTION_RETRIES}) exceeded")
        
        try:
            with self.get_connection() as connection:
                cursor = connection.cursor(dictionary=True)
                cursor.execute(query, params or ())
                
                if fetch == "all":
                    result = cursor.fetchall()
                elif fetch == "one":
                    result = cursor.fetchone()
                elif fetch == "many":
                    result = cursor.fetchmany()
                else:
                    result = None
                
                connection.commit()
                return result
                
        except Error as e:
            logger.error(f"Query execution failed (attempt {retry_count + 1}): {e}")
            logger.debug(f"Query: {query}")
            logger.debug(f"Params: {params}")
            
            if retry_count < config.performance.MAX_CONNECTION_RETRIES:
                await asyncio.sleep(config.performance.CONNECTION_RETRY_DELAY)
                return await self.execute_query(query, params, fetch, retry_count + 1)
            
            raise Exception(f"Database query failed after {retry_count + 1} attempts: {str(e)}")
    
    async def execute_batch(
        self, 
        query: str, 
        params_list: List[Tuple],
        retry_count: int = 0
    ) -> bool:
        """Execute batch query with multiple parameter sets"""
        
        if retry_count >= config.performance.MAX_CONNECTION_RETRIES:
            raise Exception(f"Max retries ({config.performance.MAX_CONNECTION_RETRIES}) exceeded")
        
        try:
            with self.get_connection() as connection:
                cursor = connection.cursor()
                cursor.executemany(query, params_list)
                connection.commit()
                return True
                
        except Error as e:
            logger.error(f"Batch execution failed (attempt {retry_count + 1}): {e}")
            
            if retry_count < config.performance.MAX_CONNECTION_RETRIES:
                await asyncio.sleep(config.performance.CONNECTION_RETRY_DELAY)
                return await self.execute_batch(query, params_list, retry_count + 1)
            
            raise Exception(f"Batch execution failed after {retry_count + 1} attempts: {str(e)}")
    
    async def test_connection(self) -> bool:
        """Test database connection"""
        try:
            with self.get_connection() as connection:
                cursor = connection.cursor()
                cursor.execute("SELECT 1")
                cursor.fetchone()
                return True
        except Exception as e:
            logger.error(f"Database connection test failed: {e}")
            return False

class TestLinkQueries:
    """TestLink-specific database queries"""
    
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
    
    async def get_tree_nodes(
        self, 
        parent_id: int, 
        tplan_id: int, 
        build_id: int, 
        platform_id: int
    ) -> List[Dict]:
        """Get tree nodes for lazy loading"""
        
        if parent_id == 0:
            # Get root test suites
            query = """
                SELECT nh.id, nh.name, 'testsuite' as type,
                       COUNT(DISTINCT tc.id) as testcase_count
                FROM nodes_hierarchy nh
                LEFT JOIN nodes_hierarchy child ON nh.id = child.parent_id
                LEFT JOIN testplan_tcversions tptc ON child.id = tptc.tcversion_id
                WHERE nh.parent_id = 0 
                  AND nh.node_type_id = 1
                  AND EXISTS (
                      SELECT 1 FROM testproject_suites tps 
                      WHERE tps.testproject_id = %s AND tps.testsuite_id = nh.id
                  )
                GROUP BY nh.id, nh.name
                ORDER BY nh.name
            """
            params = (config.testlink.DEFAULT_TESTPROJECT_ID,)
        else:
            # Get child nodes
            query = """
                SELECT nh.id, nh.name, 
                       CASE WHEN nh.node_type_id = 2 THEN 'testcase' ELSE 'testsuite' END as type,
                       CASE WHEN nh.node_type_id = 2 THEN 
                           (SELECT status FROM executions e 
                            WHERE e.tcversion_id = nh.id 
                              AND e.testplan_id = %s 
                              AND e.build_id = %s 
                              AND e.platform_id = %s 
                            ORDER BY e.id DESC LIMIT 1)
                       ELSE NULL END as status,
                       CASE WHEN nh.node_type_id = 2 THEN 0 ELSE 
                           (SELECT COUNT(DISTINCT tc.id) 
                            FROM nodes_hierarchy tc 
                            WHERE tc.parent_id = nh.id AND tc.node_type_id = 2) 
                       END as testcase_count
                FROM nodes_hierarchy nh
                WHERE nh.parent_id = %s
                ORDER BY nh.node_type_id, nh.name
            """
            params = (tplan_id, build_id, platform_id, parent_id)
        
        return await self.db.execute_query(query, params)
    
    async def get_testcase_details(self, tcversion_id: int) -> Optional[Dict]:
        """Get test case basic details"""
        
        query = """
            SELECT tc.id, tc.name, tc.summary, tc.preconditions, tc.version,
                   tc.author_id, tc.creation_ts, tc.updater_id, tc.modification_ts,
                   tc.active, tc重要性, tc.urgency,
                   u1.login as author_login, u2.login as updater_login
            FROM tcversions tc
            LEFT JOIN users u1 ON tc.author_id = u1.id
            LEFT JOIN users u2 ON tc.updater_id = u2.id
            WHERE tc.id = %s
        """
        
        return await self.db.execute_query(query, (tcversion_id,), "one")
    
    async def get_test_steps(self, tcversion_id: int) -> List[Dict]:
        """Get test case steps"""
        
        query = """
            SELECT id, step_number, actions, expected_results, execution_type
            FROM tcsteps 
            WHERE tcversion_id = %s
            ORDER BY step_number
        """
        
        return await self.db.execute_query(query, (tcversion_id,))
    
    async def get_latest_execution(
        self, 
        tcversion_id: int, 
        tplan_id: int, 
        build_id: int, 
        platform_id: int
    ) -> Optional[Dict]:
        """Get latest execution for test case"""
        
        query = """
            SELECT e.id, e.status, e.execution_ts, e.notes, e.tester_id, e.duration,
                   u.login as tester_login
            FROM executions e
            LEFT JOIN users u ON e.tester_id = u.id
            WHERE e.tcversion_id = %s 
              AND e.testplan_id = %s 
              AND e.build_id = %s 
              AND e.platform_id = %s
            ORDER BY e.id DESC 
            LIMIT 1
        """
        
        return await self.db.execute_query(
            query, 
            (tcversion_id, tplan_id, build_id, platform_id), 
            "one"
        )
    
    async def create_execution(
        self, 
        tplan_id: int, 
        tcversion_id: int, 
        build_id: int, 
        platform_id: int, 
        status: str, 
        notes: str, 
        tester_id: int
    ) -> bool:
        """Create new execution record"""
        
        query = """
            INSERT INTO executions (testplan_id, tcversion_id, build_id, platform_id, 
                                   status, notes, tester_id, execution_ts, duration) 
            VALUES (%s, %s, %s, %s, %s, %s, %s, NOW(), 0)
        """
        
        params = (tplan_id, tcversion_id, build_id, platform_id, status, notes, tester_id)
        await self.db.execute_query(query, params)
        return True
    
    async def get_execution_stats(
        self, 
        tplan_id: int, 
        build_id: int, 
        platform_id: int
    ) -> List[Dict]:
        """Get execution statistics"""
        
        query = """
            SELECT e.status, COUNT(*) as count 
            FROM executions e
            JOIN testplan_tcversions tptc ON e.testplan_id = tptc.testplan_id 
                                           AND e.tcversion_id = tptc.tcversion_id
            WHERE e.testplan_id = %s 
              AND e.build_id = %s 
              AND e.platform_id = %s
            GROUP BY e.status
        """
        
        return await self.db.execute_query(query, (tplan_id, build_id, platform_id))
    
    async def get_total_testcases(self, tplan_id: int) -> int:
        """Get total test cases count for test plan"""
        
        query = "SELECT COUNT(*) as total FROM testplan_tcversions WHERE testplan_id = %s"
        result = await self.db.execute_query(query, (tplan_id,), "one")
        return result['total'] if result else 0
    
    async def get_builds(self, tplan_id: int) -> List[Dict]:
        """Get available builds for test plan"""
        
        query = """
            SELECT id, name 
            FROM builds 
            WHERE testplan_id = %s 
            AND is_open = 1 
            ORDER BY name
        """
        
        return await self.db.execute_query(query, (tplan_id,))
    
    async def get_platforms(self, tplan_id: int) -> List[Dict]:
        """Get available platforms for test plan"""
        
        query = """
            SELECT p.id, p.name 
            FROM platforms p
            JOIN testplan_platforms tp ON p.id = tp.platform_id
            WHERE tp.testplan_id = %s
            ORDER BY p.name
        """
        
        return await self.db.execute_query(query, (tplan_id,))

# Global database manager instance
db_manager = DatabaseManager()
queries = TestLinkQueries(db_manager)
